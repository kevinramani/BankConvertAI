BankConvertAI - AI-powered Bank Statement PDF to Excel/CSV/JSON

1. To Run:
- Windows: double-click run.bat
- Mac/Linux: run `python app.py`

2. Upload a PDF bank statement
3. Download in Excel/CSV/JSON format
